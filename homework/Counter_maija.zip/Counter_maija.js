
let number = document.getElementById('numberEl')

function plus() {
    number ++
    numberEl.innerHTML = number
    
}
function minus() {
    number --
    numberEl.innerHTML = number
}