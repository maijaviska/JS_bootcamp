const AVAILABLE_wordToGuessS = ['reactor', 'bacon', 'diagram', 'minister', 'moving']

const KEYBOARD_TOP = 'QWERTYUIOP'
const KEYBOARD_MID = 'ASDFGHJKL'
const KEYBOARD_BOT = 'ZXCVBNM'


let wordToGuess = null

window.onload = function() {
    play()
}

function play() {
    wordToGuess = generateRandomwordToGuess().toUpperCase()
    displayGuestWordToGuess()
    displayVirtualKeyboard()
}

function generateRandomwordToGuess() {
    let ri = Math.floor(Math.random()*AVAILABLE_wordToGuessS.length)
    return AVAILABLE_wordToGuessS[ri]

}

function displayGuesswordToGuess() {
    let mid = document.getElementById('mid')

    let middleLetters = document.createElement('div')
    middleLetters.id = 'middleLetters'
    middleLetters.className = 'guessWord'
    mid.appendChild(middleLetters)

    for (let i = 0; i < wordToGuess.length; i++) {
        let emptyletter = document.createElement('div')
        emptyletter.className = 'letterContainer'
        emptyletter.style.color = 'transperent'
        emptyletter.innerText = wordToGuess[i]
        middleLetters.appendChild(emptyLetter)
    }

    makeFirstAndLastVisible(middleLetters)
}

function makeFirstAndLastVisible() {
    let firstLetter = wordToGuess[0]
    let lastLetter = wordToGuess[wordToGuess.length -1]

    let letters = middleLetters.children
    for (letter of letters) {
        if (letter.innerText === firstLetter || letter.innerText === lastLetter) {
            letter.style.color = 'black'
        }
    }
}


function displayVirtualKeyboard() {
    let keyboard = document.createElement('div')
    let bot = document.getElementById('bot')
    bot.appendChild(keyboard)

    displayKeyboardRow(keyboard, KEYBOARD_TOP)
    displayKeyboardRow(keyboard, KEYBOARD_MID)
    displayKeyboardRow(keyboard, KEYBOARD_BOT)

}


function displayKeyboardRow(keyboardContainer, keyboardRowLetters) {
    let keyboardRowContainer = document.createElement('div')
    keyboardRowContainer.className = 'keyboardRow'

    for (const char of keyboardRowLetters) {
        let letterContainer = document.createElement('div')
        letterContainer.className = 'letterContainer'
        letterContainer.className += ' keyboardLetter'
        letterContainer.innerText = char

        let firstLetter = wordToGuess[0]
        let lastLetter = wordToGuess[wordToGuess.length - 1]
        if (char === firstLetter || char === lastLetter) {
            letterContainer.style.pointerEvents = 'none'
            letterContainer.style.backgroundColor = 'darkgrey'
        }

        letterContainer.onclick = function() {
            let guessWordLetterIndex = wordToGuess.indexOf(char)
            if (guessWordLetterIndex !== -1) {
                let middleLetters = document.getElementById('middleLetters').children
                letterContainer.style.background = 'green'

                for (ml of middleLetters) {
                    if (wordToGuess.indexOf(ml.innerText) !== -1) {
                        ml.style.color = 'black'
                    }
                }
            } else {
                letterContainer.style.background = 'red'
            }
            letterContainer.style.pointerEvents = 'none'
        }

        keyboardRowContainer.appendChild(letterContainer)

    }

    keyboardRowContainer.appendChild(keyboardRowContainer)
}
    
