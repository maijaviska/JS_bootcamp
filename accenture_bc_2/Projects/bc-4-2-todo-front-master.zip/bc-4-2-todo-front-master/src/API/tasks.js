export function getTasks() {
    return [
        {
            id: 11,
            task: 'Foo',
            isCompleted: false,
        },
        {
            id: 12,
            task: 'Bar',
            isCompleted: true,
        },
        {
            id: 13,
            task: 'Baz',
            isCompleted: false,
        },
    ]
}